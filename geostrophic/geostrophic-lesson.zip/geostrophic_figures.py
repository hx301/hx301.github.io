"""Original analytical teaching figures; no observational data.
Run: python geostrophic_figures.py --out figures
Requires numpy and matplotlib. Configure a Chinese font on non-Windows systems.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
font=Path('C:/Windows/Fonts/msyh.ttc')
if font.exists():
    font_manager.fontManager.addfont(str(font));plt.rcParams['font.family']=font_manager.FontProperties(fname=str(font)).get_name()
plt.rcParams.update({'font.size':12,'figure.facecolor':'white','savefig.facecolor':'white','text.color':'#173b4c','axes.labelcolor':'#173b4c','axes.spines.top':False,'axes.spines.right':False})
G=9.81;OMEGA=7.292115e-5;RHO=1025.;F=2*OMEGA*np.sin(np.deg2rad(30))
BLUE='#08748b';RED='#b8593c';GOLD='#9c690f'
def save(fig,name):
    origin='Original analytical geostrophic teaching figure, not observational data. Equations and parameters in analysis/geostrophic_figures.py. g=9.81 m/s^2; Omega=7.292115e-5 s^-1; rho0=1025 kg/m^3; latitude=+/-30 deg.'
    fig.savefig(a.out/(name+'.png'),dpi=150,bbox_inches='tight',metadata={'Description':origin,'impeccable:prompt':origin})
    fig.savefig(a.out/(name+'.pdf'),bbox_inches='tight',metadata={'Title':name,'Subject':origin});plt.close(fig)

checks={'f_30_per_s':F,'linear_slope':.2/100000,'v_30_m_per_s':G/F*.2/100000,'rossby_U_03_L_100km':.3/(F*100000)}
assert abs(checks['v_30_m_per_s']-.26905774250680364)<1e-10
for language in ['zh','en']:
    zh=language=='zh';T=lambda z,e:z if zh else e
    # Signs are shown as distinct physical acceleration vectors, not momentum-equation terms.
    fig,axs=plt.subplots(1,2,figsize=(12,5),layout='constrained')
    for ax,hem in zip(axs,[1,-1]):
        ax.set(xlim=(-1.65,1.65),ylim=(-1.5,1.6),aspect='equal');ax.axis('off')
        ax.text(0,1.4,T('北半球 · f > 0','Northern hemisphere · f > 0') if hem==1 else T('南半球 · f < 0','Southern hemisphere · f < 0'),ha='center',weight='bold',fontsize=15)
        ax.text(1.3,.55,T('高压','High p'),ha='center');ax.text(-1.3,.55,T('低压','Low p'),ha='center')
        for end,color in [((-1.05,0),RED),((1.05,0),GOLD),((0,hem*.95),BLUE)]:
            ax.annotate('',xy=end,xytext=(0,0),arrowprops={'arrowstyle':'-|>','color':color,'lw':3,'mutation_scale':20})
        ax.plot(0,0,'o',color='#173b4c',ms=5)
        ax.text(-.65,-.25,T('压力梯度加速度','Pressure-gradient acceleration'),color=RED,ha='center',fontsize=10)
        ax.text(.72,-.45,T('科氏加速度','Coriolis acceleration'),color=GOLD,ha='center',fontsize=10)
        ax.text(.16,hem*.8,T('地转速度','Geostrophic velocity'),color=BLUE,fontsize=11)
        ax.text(0,-1.28,T('红/金：相等相反的加速度；蓝：速度，单位不同','Red/gold: equal opposite accelerations; blue: velocity, different units'),ha='center',fontsize=9)
    save(fig,'force-balance-'+language)

    x=np.linspace(0,100,101);eta=.2*x/100
    fig,axs=plt.subplots(1,2,figsize=(12,4.2),layout='constrained')
    axs[0].plot(x,eta,c=BLUE,lw=2);axs[0].fill_between(x,0,eta,color='#d5edf3');axs[0].set(xlabel=T('向东距离 / km','Eastward distance / km'),ylabel=T('海面高度 η / m','Sea level η / m'),title=T('向东升高 0.20 m / 100 km','Sea level rises eastward by 0.20 m / 100 km'))
    axs[1].plot(x,RHO*G*eta/1000,c=RED,lw=2);axs[1].set(xlabel=T('向东距离 / km','Eastward distance / km'),ylabel=T('同深度压力差 / kPa','Pressure difference at fixed depth / kPa'),title=T('同一深度：东侧水柱更重','At fixed depth: a heavier water column to the east'))
    fig.supxlabel(T('均匀密度、静力平衡、水平大气压梯度忽略；高度与横轴比例刻意放大。','Uniform density, hydrostatic balance, negligible horizontal atmospheric pressure gradient; vertical scale exaggerated.'),fontsize=9)
    save(fig,'surface-pressure-'+language)

    coord=np.linspace(-200000,200000,81);xx,yy=np.meshgrid(coord,coord);sigma=100000.
    fig,axs=plt.subplots(2,2,figsize=(10,9),layout='constrained')
    for ax,(hem,amp) in zip(axs.flat,[(1,.2),(1,-.2),(-1,.2),(-1,-.2)]):
        eta=amp*np.exp(-(xx*xx+yy*yy)/(2*sigma*sigma));ex=-xx/sigma**2*eta;ey=-yy/sigma**2*eta;u=-G/(hem*F)*ey;v=G/(hem*F)*ex
        assert np.max(abs(u*ex+v*ey))<1e-18
        assert np.max(abs(-G*ex+(hem*F)*v))<1e-15
        image=ax.contourf(xx/1000,yy/1000,eta,levels=np.linspace(-.2,.2,21),cmap='RdBu_r',vmin=-.2,vmax=.2)
        ax.contour(xx/1000,yy/1000,eta,levels=np.linspace(-.2,.2,9),colors='#708a98',linewidths=.5)
        ax.quiver(xx[::8,::8]/1000,yy[::8,::8]/1000,u[::8,::8],v[::8,::8],color='#173b4c',scale=2.6,width=.006)
        direction=('顺时针' if (hem==1)==(amp>0) else '逆时针') if zh else ('clockwise' if (hem==1)==(amp>0) else 'counterclockwise')
        ax.set(aspect='equal',xlabel=T('向东 / km','East / km'),ylabel=T('向北 / km','North / km'),title=T('北半球' if hem==1 else '南半球','NH' if hem==1 else 'SH')+' · '+T('海面凸起' if amp>0 else '海面凹陷','SSH dome' if amp>0 else 'SSH trough')+' · '+direction)
    fig.colorbar(image,ax=axs,shrink=.85,label=T('教学海面高度 / m','Teaching sea level / m'));fig.supxlabel(T('解析高斯模型；箭头为由海面坡度诊断的地转分量。有限曲率时，精确流动还需向心加速度。','Analytical Gaussian model: arrows show diagnosed geostrophic components. Exact curved flow also requires centripetal acceleration.'),fontsize=9)
    save(fig,'hemisphere-currents-'+language)

    # Stable Boussinesq density field: rho_z<0; eastward density increase gives negative v_z.
    xc=np.linspace(0,100000,101);zc=np.linspace(-500,0,101);xxz,zz=np.meshgrid(xc,zc)
    rho=1025-.003*zz+1e-5*xxz;shear=-G/(RHO*F)*1e-5
    fig,axs=plt.subplots(1,2,figsize=(12,5),layout='constrained')
    im=axs[0].contourf(xxz/1000,zz,rho,levels=15,cmap='YlGnBu');cs=axs[0].contour(xxz/1000,zz,rho,levels=[1026,1027],colors='#173b4c');axs[0].clabel(cs,fmt='%.1f',fontsize=10);axs[0].set(xlabel=T('向东 / km','East / km'),ylabel=T('z / m（向上为正）','z / m (positive upward)'),title=T('水平密度梯度：东侧更密','Horizontal density gradient: denser to the east'));fig.colorbar(im,ax=axs[0],label='kg/m³')
    relative=shear*(zc+500);axs[1].plot(relative,zc,c=BLUE,lw=2,label=T('假设 v(−500 m) = 0','Assume v(−500 m) = 0'));axs[1].plot(relative+.4,zc,'--',c=RED,lw=2,label=T('改为 v(−500 m) = +0.4 m/s','Instead v(−500 m) = +0.4 m/s'));axs[1].axvline(0,c='#8fa8b4',lw=.8);axs[1].set(xlabel=T('向北速度 v / m/s','Northward velocity v / m/s'),ylabel='z / m',title=T('同一剪切，不同参考流速','Same shear, different reference velocities'));axs[1].legend(fontsize=9,loc='lower right')
    fig.supxlabel(T('30°N；rho_x = 10^-5 kg/m^4；∂v/∂z = −grho_x/(rho0f)。曲线仅为解析教学例。','30°N; rho_x = 10^-5 kg/m^4; ∂v/∂z = −grho_x/(rho0f). Curves are analytical teaching examples.'),fontsize=10)
    save(fig,'thermal-wind-'+language)

    # From rest under a constant east-west pressure force, an inviscid parcel never settles.
    vg=G/F*.2/100000;phase=np.linspace(0,4*np.pi,600);u=-vg*np.sin(phase);v=vg*(1-np.cos(phase))
    fig,axs=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    axs[0].plot(phase/(2*np.pi),u,c=RED,label='u');axs[0].plot(phase/(2*np.pi),v,c=BLUE,label='v');axs[0].axhline(vg,c=GOLD,ls='--',label='v_g');axs[0].set(xlabel=T('时间 / 惯性周期','Time / inertial period'),ylabel='m/s',title=T('静止出发：围绕地转解振荡','Starting from rest: oscillation around geostrophy'));axs[0].legend()
    axs[1].plot(u,v,c=BLUE);axs[1].plot(0,vg,'o',c=GOLD,label=T('地转平衡速度','Geostrophic velocity'));axs[1].plot(0,0,'o',c=RED,label=T('初始静止','Initially at rest'));axs[1].set(aspect='equal',xlabel='u / m/s',ylabel='v / m/s',title=T('速度空间中的惯性圆','Inertial circle in velocity space'));axs[1].legend(fontsize=10)
    assert np.max(abs(u*u+(v-vg)**2-vg*vg))<1e-14
    fig.supxlabel(T('固定海面坡度、f 平面、无摩擦的质点模型；不是完整海盆的地转调整。','Fixed pressure gradient, f plane, inviscid parcel model; not a complete basin geostrophic-adjustment model.'),fontsize=10)
    save(fig,'inertial-adjustment-'+language)

(a.out/'figure-checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks,indent=2))
