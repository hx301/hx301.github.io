NOAA PMEL TAO station EOF lesson / 真实海温 EOF 课程
Snapshot downloaded 2026-10-14. See analysis-summary.json for query, SHA-256, versions and processing.
Install: python -m pip install numpy pandas matplotlib
Run analysis:
python analyze.py --raw tao-equatorial-1m-2000-2024.csv --out results
Run bilingual map / PC atlas:
python plot_atlas.py --data results --land ne_110m_land.geojson
The atlas uses Microsoft YaHei on Windows (C:/Windows/Fonts/msyh.ttc). On other systems, change the font path in plot_atlas.py to an installed Chinese font before generating Chinese panels. English figures need no additional font.
No interpolation; equal station weights. PCs have sample SD 1; loadings are degrees C per PC SD.
Land outlines are Natural Earth 1:110m, public domain. Source and SHA-256 are in atlas-provenance.json.
Full lesson: https://hx301.github.io/tao-eof.html
