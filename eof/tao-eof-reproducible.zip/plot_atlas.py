"""Figure-led EOF atlas from the verified model and public-domain Natural Earth land.
Run: python plot_atlas.py --data results --land ne_110m_land.geojson
The maps show discrete observed station loadings, with no spatial interpolation.
"""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection
from matplotlib import font_manager

p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--land',type=Path,required=True);a=p.parse_args()
d=json.loads((a.data/'model.json').read_text(encoding='utf-8'));land=json.loads(a.land.read_text(encoding='utf-8'))
font=Path('C:/Windows/Fonts/msyh.ttc')
if font.exists():font_manager.fontManager.addfont(str(font));plt.rcParams['font.family']=font_manager.FontProperties(fname=str(font)).get_name()
else:plt.rcParams['font.family']=['DejaVu Sans']
plt.rcParams.update({'font.size':13,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#173b4c','text.color':'#173b4c','figure.facecolor':'white','savefig.facecolor':'white'})
polygons=[]
for f in land['features']:
    geom=f['geometry'];groups=geom['coordinates'] if geom['type']=='MultiPolygon' else [geom['coordinates']]
    for poly in groups:
        # Unwrap each ring across the date line; replicate shifted polygons, then clip to axes.
        ring=np.array(poly[0]);xx=np.rad2deg(np.unwrap(np.deg2rad(ring[:,0])));yy=ring[:,1]
        for shift in [-360,0,360,720]:
            coords=np.column_stack([xx+shift,yy]);
            if coords[:,0].max()>=120 and coords[:,0].min()<=280:polygons.append(Polygon(coords,closed=True))
labels=d['stations'];lons=d['longitudes'];load=np.array(d['loadings']);pc=np.array(d['pc']);dates=pd.to_datetime(d['dates']);all_dates=pd.date_range('2000-01-01','2024-12-01',freq='MS')
limit=1.2;norm=TwoSlopeNorm(vmin=-limit,vcenter=0,vmax=limit);cmap=plt.get_cmap('RdBu_r')
def save(fig,name):
    provenance='Original Matplotlib scientific plot from NOAA PMEL TAO, analysis/analyze.py and analysis/plot_atlas.py. Discrete station loadings; no spatial interpolation. Land: Natural Earth 1:110m, public domain. Raw SHA256: '+d['raw_sha256']
    fig.savefig(a.data/(name+'.png'),dpi=160,bbox_inches='tight',metadata={'Description':provenance,'impeccable:prompt':provenance})
    fig.savefig(a.data/(name+'.pdf'),bbox_inches='tight',metadata={'Title':name,'Author':'Ocean course','Subject':provenance});plt.close(fig)
for language in ['zh','en']:
    zh=language=='zh'
    for k in range(3):
        fig,ax=plt.subplots(figsize=(8,4.6),layout='constrained')
        ax.set_facecolor('#eff8fc');ax.add_collection(PatchCollection(polygons,facecolor='#d2dfe6',edgecolor='#8da8b5',linewidth=.6,zorder=1))
        ax.set_xlim(120,280);ax.set_ylim(-22,22);ax.set_xticks([120,160,180,220,260,280],['120°E','160°E','180°','140°W','100°W','80°W']);ax.set_yticks([-20,0,20],['20°S','0°','20°N']);ax.grid(color='#d0e2ea',linewidth=.6);ax.axhline(0,c='#8baab9',lw=.8,ls='--');ax.tick_params(labelsize=12)
        sc=ax.scatter(lons,[0]*5,c=load[:,k],cmap=cmap,norm=norm,s=260,edgecolors='#274c60',linewidths=1.1,zorder=4)
        for j,(x,s) in enumerate(zip(lons,labels)):
            y=7 if j%2==0 else -10
            ax.annotate(s+'\n'+f'{load[j,k]:+.2f}',xy=(x,0),xytext=(x,y),ha='center',va='center',fontsize=11,color='#173b4c',arrowprops={'arrowstyle':'-','color':'#748d98','lw':.7},zorder=5)
        ax.set_title(f'EOF {k+1} · '+('空间分布' if zh else 'Spatial loading')+f' · {d["fraction"][k]*100:.2f}%',loc='left',fontsize=16,fontweight='bold',pad=14)
        cb=fig.colorbar(sc,ax=ax,orientation='horizontal',fraction=.055,pad=.13,aspect=38);cb.set_label('空间载荷 / °C 每个 PC 标准差' if zh else 'Spatial loading / °C per PC standard deviation',fontsize=12)
        fig.supxlabel('圆点是观测站；空白海域没有估计值。底图：Natural Earth。' if zh else 'Dots are observed stations; blank ocean has no estimated values. Land: Natural Earth.',fontsize=10)
        save(fig,f'atlas-eof{k+1}-map-{language}')
        fig,ax=plt.subplots(figsize=(8,4.6),layout='constrained');full=pd.Series(pc[:,k],index=dates).reindex(all_dates)
        ax.axhline(0,c='#96afbc',lw=.8);ax.fill_between(full.index,0,full,where=full>=0,color='#d06844',alpha=.4);ax.fill_between(full.index,0,full,where=full<0,color='#207fba',alpha=.4)
        ax.plot(full.index,full,color='#126086',lw=1.4,marker='.',ms=3);ax.set_xlim(all_dates[0],all_dates[-1]);ax.set_ylim(-4,4);ax.set_yticks([-4,-2,0,2,4]);ax.grid(axis='y',color='#dfebef',lw=.6);ax.set_ylabel('标准差' if zh else 'Standard deviations');ax.set_xlabel('年份' if zh else 'Year')
        ax.set_title(f'PC {k+1} · '+('时间系数' if zh else 'Time coefficient'),loc='left',fontsize=16,fontweight='bold',pad=14)
        fig.supxlabel('108 个共同月份；断线处为缺测。每个 PC 的样本标准差为 1。' if zh else '108 shared months; breaks show missing data. Each PC has sample SD = 1.',fontsize=10)
        save(fig,f'atlas-eof{k+1}-pc-{language}')
manifest={'data_source':d['source'],'raw_sha256':d['raw_sha256'],'land_source':'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_land.geojson','land_sha256':hashlib.sha256(a.land.read_bytes()).hexdigest(),'land_license':'Public domain, https://www.naturalearthdata.com/about/terms-of-use/','maps':'Equal-weight station EOF loadings, no interpolation','color_limits_C_per_PC_SD':[-limit,limit],'pc_axis_limits_SD':[-4,4]}
(a.data/'atlas-provenance.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print('Generated 12 bilingual PNG/PDF atlas panels.')
