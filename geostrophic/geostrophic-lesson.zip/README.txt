Geostrophic-current teaching figures / 地转流教学图与复算代码
All figures are original analytical teaching models, not observed ocean currents.
Coordinates: x east, y north, z up. f=2 Omega sin(latitude).
g=9.81 m/s^2; Omega=7.292115e-5 s^-1; rho0=1025 kg/m^3.
Force per mass: pressure=-grad(p)/rho0; Coriolis=(fv,-fu).
Geostrophy: u=-p_y/(rho0*f); v=p_x/(rho0*f).
Uniform-density surface form: u=-g*eta_y/f; v=g*eta_x/f.
Thermal wind (Boussinesq, z up): u_z=g*rho_y/(rho0*f); v_z=-g*rho_x/(rho0*f).
Planar example: eta rises 0.20 m eastward over100km at30N; v=.26905774250680364m/s, northward. Reverse latitude to reverse velocity.
Gaussian sea level: eta=A exp(-(x^2+y^2)/(2 sigma^2)), A=+/-0.20m, sigma=100km. Four hemisphere/sign cases show approximate geostrophic components. Exact curved flow also has centripetal acceleration.
Thermal-wind example: rho=1025-0.003z+1e-5x (SI units), stable stratification; density increases eastward. v_z<0 at30N. The two velocity profiles differ only by their reference velocities at-500m.
Inviscid parcel under constant pressure force from rest: u=-vg sin(ft), v=vg(1-cos(ft)). This oscillates around the geostrophic solution; it is not a full ocean-basin adjustment simulation.
10 PNGs and10 matching PDFs; captions and labels in Chinese and English. Each PNG embeds its origin metadata.
Reproduce:
  python -m pip install numpy matplotlib
  python geostrophic_figures.py --out figures
Windows plotting attempts Microsoft YaHei. Other systems need a Chinese font configured in matplotlib to render Chinese labels. Fonts do not change numerical results.
The website lab is kinematic flow in a fixed constant-f field, not a dynamical spin-up calculation. Its |latitude|<5degree guard is a UI safeguard, not a universal physical criterion. Ro must be small and local/time accelerations/friction must also be assessed.
Sources and full bilingual chapter content are in lesson-content.json.
