"""Independent ERSSTv5 EOF lesson. numpy, pandas, matplotlib, netCDF4.
python grid_eof.py --raw-dir monthly --out results --land ne_110m_land.geojson
Or reproduce from the packaged spatial subset: --subset sst-subset.npz
"""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection
from matplotlib import font_manager

p=argparse.ArgumentParser();p.add_argument('--raw-dir',type=Path);p.add_argument('--subset',type=Path);p.add_argument('--out',type=Path,required=True);p.add_argument('--land',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
if a.subset:
    z=np.load(a.subset);sst=z['sst'];lats=z['lats'];lons=z['lons'];dates=z['dates'].astype(str)
else:
    from netCDF4 import Dataset
    files=sorted(a.raw_dir.glob('ersst.v5.*.nc'));assert len(files)==564,len(files)
    rows=[];dates=[]
    for f in files:
        with Dataset(f) as ds:
            lat=np.asarray(ds['lat'][:]);lon=np.asarray(ds['lon'][:]);iy=np.where(abs(lat)<=20)[0];ix=np.where((lon>=120)&(lon<=280))[0]
            field=np.ma.filled(ds['sst'][0,0,:,:],np.nan).astype(float);rows.append(field[np.ix_(iy,ix)])
        stamp=f.name.split('.')[2];dates.append(stamp[:4]+'-'+stamp[4:])
    sst=np.array(rows);lats=lat[iy];lons=lon[ix];dates=np.array(dates)
np.savez_compressed(a.out/'sst-subset.npz',sst=sst,lats=lats,lons=lons,dates=dates)
assert sst.shape==(564,21,81) and dates[0]=='1979-01' and dates[-1]=='2025-12'
valid=np.isfinite(sst).all(axis=0)&(abs(sst)<100).all(axis=0)
flat=sst[:,valid];n,m=flat.shape;months=pd.to_datetime(dates).month.to_numpy();baseline=(dates>='1991-01')&(dates<='2020-12')
clim=np.array([flat[baseline&(months==i)].mean(axis=0) for i in range(1,13)])
anom=flat-clim[months-1];t=np.arange(n,dtype=float);t-=t.mean();offset=anom.mean(axis=0);slope=(t@anom)/(t@t);trend=offset+t[:,None]*slope;X=anom-trend
latgrid,longrid=np.meshgrid(lats,lons,indexing='ij');w=np.sqrt(np.cos(np.deg2rad(latgrid[valid])));Y=X*w
U,s,Vt=np.linalg.svd(Y,full_matrices=False)
for k in range(len(s)):
    if Vt[k,np.argmax(abs(Vt[k]))]<0:Vt[k]*=-1;U[:,k]*=-1
eigen=s*s/(n-1);fraction=eigen/eigen.sum();pc=U*np.sqrt(n-1);loading=Vt.T*s/np.sqrt(n-1)/w[:,None]
assert np.max(abs(X.mean(axis=0)))<1e-12
assert np.allclose(Vt@Vt.T,np.eye(n),atol=1e-12)
assert np.allclose(pc[:,:8].T@pc[:,:8]/(n-1),np.eye(8),atol=1e-12)
full=pc@loading.T;err=float(np.max(abs(full-X)));assert err<1e-10
weighted_rmse=[float(np.sqrt(np.sum((Y-(pc[:,:k]@loading[:,:k].T)*w)**2)/(n*np.sum(w*w)))) for k in [1,2,3,5,8]]
# Sensitivity: same sample/domain/area weights, retain linear trends.
Y0=(anom-anom.mean(axis=0))*w;u0,s0,v0=np.linalg.svd(Y0,full_matrices=False)
sensitivity={'without_detrending_first_fraction':float(s0[0]**2/np.sum(s0*s0)),'abs_weighted_eof1_cosine':float(abs(v0[0]@Vt[0]))}
summary={'dataset':'NOAA NCEI ERSSTv5','period':[str(dates[0]),str(dates[-1])],'months':n,'ocean_cells':m,'grid_shape':[21,81],'masked_cells':int(valid.size-m),'climatology':'1991–2020, per calendar month','detrending':'Gridwise OLS intercept and linear trend removed after seasonal climatology subtraction','weighting':'sqrt(cos(latitude)); covariance EOF, no per-cell standard-deviation normalization','pc_scaling':'PC = sqrt(N-1) U; sample SD = 1','loading_scaling':'L = W^-1 V S / sqrt(N-1), degrees C per PC SD','sign_convention':'Largest absolute weighted loading positive for each mode','variance_fraction':fraction[:12].tolist(),'cumulative_fraction':np.cumsum(fraction[:12]).tolist(),'weighted_rmse_by_rank':dict(zip(['1','2','3','5','8'],weighted_rmse)),'full_reconstruction_max_error_C':err,'sensitivity':sensitivity,'downloaded':'2026-10-14','source':'https://www.ncei.noaa.gov/data/sea-surface-temperature-extended-reconstructed/v5/netcdf/','land':'Natural Earth 1:110m, public domain','subset_sha256':hashlib.sha256((a.out/'sst-subset.npz').read_bytes()).hexdigest(),'interpretation':'Fractions describe the area-weighted detrended anomaly sample. ERSST is an observation-based reconstructed product, not direct measurements at every grid cell.'}
(a.out/'analysis-summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
pd.DataFrame(pc[:,:8],index=dates,columns=[f'PC{i}' for i in range(1,9)]).to_csv(a.out/'principal-components.csv',index_label='month')
pd.DataFrame({'mode':np.arange(1,n+1),'eigenvalue':eigen,'fraction':fraction,'cumulative':np.cumsum(fraction)}).to_csv(a.out/'variance.csv',index=False)
pd.DataFrame({'latitude':latgrid[valid],'longitude':longrid[valid],**{f'EOF{k+1}_C_per_PC_SD':loading[:,k] for k in range(8)}}).to_csv(a.out/'spatial-loadings.csv',index=False)
pd.DataFrame({'month':dates,'area_weighted_anomaly_mean':np.average(X,axis=1,weights=w*w)}).to_csv(a.out/'area-mean.csv',index=False)
np.savez_compressed(a.out/'analysis-arrays.npz',X=X,climatology=clim,trend_offset=offset,trend_slope=slope,weights=w,pc=pc[:,:8],loading=loading[:,:8],valid=valid,lats=lats,lons=lons,dates=dates)
browser={**summary,'dates':dates.tolist(),'lats':lats.tolist(),'lons':lons.tolist(),'valid':np.flatnonzero(valid).tolist(),'anomaly_mC':np.rint(X*1000).astype(int).tolist(),'climatology':np.round(clim,4).tolist(),'trend_offset':offset.tolist(),'trend_slope':slope.tolist(),'pc':np.round(pc[:,:8],7).tolist(),'loadings':np.round(loading[:,:8],7).tolist(),'fraction':fraction[:12].tolist()}
(a.out/'model.js').write_text('window.GRID_EOF='+json.dumps(browser,separators=(',',':'))+';',encoding='utf-8')
# Tiny matrix uses the same physical scaling and is explicitly a teaching example.
toy=np.array([[-1.,-2.],[0.,0.],[1.,2.]]);assert np.allclose(toy.T@toy/2,[[1,2],[2,4]])
font=Path('C:/Windows/Fonts/msyh.ttc')
if font.exists():font_manager.fontManager.addfont(str(font));plt.rcParams['font.family']=font_manager.FontProperties(fname=str(font)).get_name()
plt.rcParams.update({'font.size':12,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','savefig.facecolor':'white','text.color':'#173b4c','axes.labelcolor':'#173b4c'})
land=json.loads(a.land.read_text());polys=[];rings=[]
for f in land['features']:
    geom=f['geometry'];groups=geom['coordinates'] if geom['type']=='MultiPolygon' else [geom['coordinates']]
    for poly in groups:
        ring=np.array(poly[0]);xx=np.rad2deg(np.unwrap(np.deg2rad(ring[:,0])));yy=ring[:,1]
        for shift in [-360,0,360,720]:
            coords=np.column_stack([xx+shift,yy])
            if coords[:,0].max()>=119 and coords[:,0].min()<=281:polys.append(Polygon(coords,closed=True));rings.append(np.round(coords,3).tolist())
(a.out/'land.js').write_text('window.EOF_LAND='+json.dumps(rings,separators=(',',':'))+';',encoding='utf-8')
def mapplot(ax,values,title,lim=1.5,cmap='RdBu_r',vmin=None):
    field=np.full(valid.shape,np.nan);field[valid]=values
    im=ax.pcolormesh(lons,lats,field,cmap=cmap,vmin=-lim if vmin is None else vmin,vmax=lim,shading='nearest',rasterized=True)
    ax.add_collection(PatchCollection(polys,facecolor='#d6e1e7',edgecolor='#7793a3',linewidth=.45,zorder=3))
    ax.set_xlim(120,280);ax.set_ylim(-20,20);ax.set_xticks([120,160,180,220,260,280],['120°E','160°E','180°','140°W','100°W','80°W']);ax.set_yticks([-20,0,20],['20°S','0°','20°N']);ax.tick_params(labelsize=10);ax.set_title(title,loc='left',fontsize=15,fontweight='bold',pad=12);return im
def save(fig,name):
    origin='Original scientific figure from independently calculated NOAA NCEI ERSSTv5 tropical Pacific SST 1979-2025; analysis/grid_eof.py; Natural Earth public-domain land. Subset SHA256 '+summary['subset_sha256']
    fig.savefig(a.out/(name+'.png'),dpi=160,bbox_inches='tight',metadata={'Description':origin,'impeccable:prompt':origin});fig.savefig(a.out/(name+'.pdf'),bbox_inches='tight',metadata={'Title':name,'Subject':origin});plt.close(fig)
dt=pd.to_datetime(dates)
for lang in ['zh','en']:
    zh=lang=='zh'
    for k in range(3):
        fig,ax=plt.subplots(figsize=(8,4.6),layout='constrained');im=mapplot(ax,loading[:,k],f'EOF {k+1} · '+('空间模态' if zh else 'Spatial pattern')+f' · {fraction[k]*100:.2f}%')
        cb=fig.colorbar(im,ax=ax,orientation='horizontal',fraction=.055,pad=.12);cb.set_label('空间载荷 / °C 每个 PC 标准差' if zh else 'Loading / °C per PC standard deviation')
        fig.supxlabel('ERSSTv5 · 1979—2025 · 去趋势 · 面积加权' if zh else 'ERSSTv5 · 1979–2025 · Detrended · Area weighted',fontsize=10);save(fig,f'eof{k+1}-map-{lang}')
        fig,ax=plt.subplots(figsize=(8,4.6),layout='constrained');v=pc[:,k];ax.axhline(0,c='#91a5b2',lw=.8);ax.plot(dt,v,c='#126086',lw=1);ax.fill_between(dt,0,v,where=v>=0,color='#c97050',alpha=.5);ax.fill_between(dt,0,v,where=v<0,color='#3187b5',alpha=.45);ax.set_ylim(-4,4);ax.set_xlim(dt[0],dt[-1]);ax.set_ylabel('标准差' if zh else 'Standard deviations');ax.set_title(f'PC {k+1} · '+('时间系数' if zh else 'Time coefficient'),loc='left',fontsize=15,fontweight='bold',pad=12);ax.grid(axis='y',alpha=.18);fig.supxlabel('每个 PC 的样本标准差为 1；正负号需和空间模态一起看。' if zh else 'Sample SD = 1. Read the sign together with its spatial pattern.',fontsize=10);save(fig,f'eof{k+1}-pc-{lang}')
    fig,axs=plt.subplots(1,2,figsize=(13,4.3),layout='constrained');xs=np.arange(1,13);axs[0].bar(xs,fraction[:12]*100,color='#0e7793');axs[0].set(xlabel='EOF',ylabel='%' ,title='方差贡献率' if zh else 'Explained variance');axs[1].plot(xs,np.cumsum(fraction[:12])*100,'o-',c='#0e7793');axs[1].set(xlabel='K',ylabel='%',ylim=(0,100),title='累计保留的信息' if zh else 'Cumulative variance retained');save(fig,'variance-'+lang)
    i=list(dates).index('1997-12');fig,axs=plt.subplots(2,2,figsize=(14,8),layout='constrained')
    fields=[flat[i],clim[11],anom[i],X[i]];titles=['原始海温','12 月气候态','扣除季节背景后的距平','再去除线性趋势'] if zh else ['Raw SST','December climatology','Seasonal anomaly','After linear detrending']
    for j,(ax,v,title) in enumerate(zip(axs.flat,fields,titles)):
        im=mapplot(ax,v,title+(' · 1991–2020' if j==1 else ' · 1997-12'),lim=33 if j<2 else 7,cmap='YlOrRd' if j<2 else 'RdBu_r',vmin=15 if j<2 else None);fig.colorbar(im,ax=ax,orientation='horizontal',fraction=.05,pad=.1).set_label('°C')
    save(fig,'preprocess-'+lang)
    fig,axs=plt.subplots(3,1,figsize=(12,8.5),layout='constrained');r=pc[i,:3]@loading[:,:3].T
    for ax,v,title in zip(axs,[X[i],r,X[i]-r],['预处理后的距平','前三模态重建','残差：原场减重建'] if zh else ['Preprocessed anomaly','Reconstruction with 3 modes','Residual: field minus reconstruction']):
        im=mapplot(ax,v,title+' · 1997-12',lim=7);fig.colorbar(im,ax=ax,fraction=.025,pad=.02).set_label('°C')
    save(fig,'reconstruction-'+lang)
print(json.dumps({k:summary[k] for k in ['months','ocean_cells','variance_fraction','sensitivity','full_reconstruction_max_error_C']},indent=2),flush=True)
