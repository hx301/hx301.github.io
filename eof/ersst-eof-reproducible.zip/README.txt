EOF 海温教学数据与复现包 / EOF ocean-temperature reproducibility pack

数据 / Data
NOAA NCEI ERSSTv5, January 1979–December 2025, downloaded 2026-10-14.
2° grid, 20°S–20°N, 120°E–80°W. 564 months, 1,626 complete ocean cells.
This is an observation-based reconstructed SST product, not direct observations at every grid cell.
This fixed teaching sample is not a live monitoring product. ERSSTv5 is the selected version, not a claim to be the latest version.
产品 / Product: https://www.ncei.noaa.gov/products/extended-reconstructed-sst
DOI: https://doi.org/10.7289/V5T72FNM
Files: https://www.ncei.noaa.gov/data/sea-surface-temperature-extended-reconstructed/v5/netcdf/

复现 / Reproduce
Unzip into a directory. Install Python packages:
  python -m pip install numpy pandas matplotlib
  python grid_eof.py --subset sst-subset.npz --out reproduced --land ne_110m_land.geojson

sst-subset.npz contains the original selected SST values, including NaN land/missing cells; no preprocessing or rounding has been applied.
source-manifest.json lists all 564 original file names, byte counts and SHA256 values, and the subset hash. To download a source file, append its file name to base_url. NOAA can revise archive files; hashes identify the exact downloaded snapshot.
For full monthly NetCDF inputs, also install netCDF4, and run:
  python grid_eof.py --raw-dir monthly --out reproduced --land ne_110m_land.geojson
The raw monthly directory must contain exactly ersst.v5.197901.nc through ersst.v5.202512.nc.

方法 / Method
1. Keep grid cells complete for the whole sample; remove 75 missing/land cells.
2. Subtract each calendar month's 1991–2020 climatology.
3. Fit and subtract each cell's OLS intercept and linear trend over all 564 months.
4. Y = X * sqrt(cos(latitude)); covariance EOF, no per-cell standard-deviation normalization.
5. SVD Y = U S V^T. PC = sqrt(N-1) U has sample SD = 1.
6. L = W^-1 V S / sqrt(N-1), in °C per PC standard deviation.
7. X_K = PC[:, :K] @ L[:, :K].T. Restore trend/intercept and climatology to recover raw SST.
8. Largest absolute weighted loading is chosen positive for each mode. Simultaneously reversing PC and L changes no reconstruction.

分析结果 / Results
EOF1 56.336013%; EOF2 13.390672%; EOF3 5.068354%; first 3 total 74.795039%.
These fractions describe this area-weighted detrended sample; they are not significance levels or forecasting scores.
analysis-arrays.npz stores full-precision X, climatology, trend coefficients, square-root area weights, the first 8 PCs and physical loadings, mask and coordinates. The script recomputes the full SVD.
principal-components.csv and spatial-loadings.csv contain the first 8 modes; variance.csv contains all economy-SVD eigenvalues.
analysis-summary.json records conventions, errors, and a no-detrending sensitivity check.

图件 / Figures
18 original PNG figures and matching PDF files, Chinese and English. Maps and PCs use consistent scales across modes. Raw SST: 15–33°C; anomaly/reconstruction/residual maps: ±7°C; EOF loading maps: ±1.5°C per PC SD; PCs: ±4 SD.
Chinese plotting uses Microsoft YaHei when available at C:/Windows/Fonts/msyh.ttc. On other systems, install and configure a Chinese font in matplotlib before rendering Chinese labels; numerical results do not depend on fonts.
Natural Earth land polygons are public domain, source recorded in source-manifest.json.
Browser maps use rounded values for delivery; CSV/NPZ outputs retain full numerical precision.

中文说明
本包可以完整复现本站 EOF 结果。分析对象是去季节、去线性趋势后的海温异常，不能把重建异常当作海温绝对值。PC 的正负必须结合空间载荷读取；整体符号没有唯一物理意义。高解释方差并不证明物理机制或统计显著性。本课程不包含 Niño 指数板块。
