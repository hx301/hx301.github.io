"""Original teaching figures for five ocean-dynamics questions, not observations.
python dynamics_homework_figures.py --out figures
Requires numpy and matplotlib; configure a Chinese font on non-Windows systems.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
font=Path('C:/Windows/Fonts/msyh.ttc')
if font.exists():font_manager.fontManager.addfont(str(font));plt.rcParams['font.family']=font_manager.FontProperties(fname=str(font)).get_name()
plt.rcParams.update({'font.size':12,'figure.facecolor':'white','savefig.facecolor':'white','text.color':'#173b4c','axes.labelcolor':'#173b4c','axes.spines.top':False,'axes.spines.right':False})
O=7.292115e-5
def save(fig,name):
    origin='Original analytical ocean-dynamics homework teaching figure; not observations. Equations and parameters in analysis/dynamics_homework_figures.py. Omega=7.292115e-5 s^-1. PV plots are dimensionless algebraic examples.'
    fig.savefig(a.out/(name+'.png'),dpi=150,bbox_inches='tight',metadata={'Description':origin,'impeccable:prompt':origin});fig.savefig(a.out/(name+'.pdf'),bbox_inches='tight',metadata={'Title':name,'Subject':origin});plt.close(fig)
for lang in ['zh','en']:
    T=lambda z,e:z if lang=='zh' else e
    lat=np.linspace(1,90,500);period=2*np.pi/(2*O*np.sin(np.deg2rad(lat)))/3600
    fig,ax=plt.subplots(figsize=(10,4.5),layout='constrained');ax.plot(lat,period,c='#08748b',lw=2);ax.scatter([30,90],[2*np.pi/O/3600,np.pi/O/3600],c='#b8593c',zorder=3)
    ax.set(yscale='log',xlim=(0,90),xlabel=T('纬度绝对值 / 度','Absolute latitude / degrees'),ylabel=T('水平惯性周期 / 小时（对数轴）','Horizontal inertial period / hours (log scale)'),title=T('离赤道越近，f 平面惯性周期越长','The f-plane period grows toward the equator'))
    ax.set_xticks([0,30,60,90]);ax.grid(axis='y',alpha=.2);ax.annotate(T('30°：23.934 h','30°: 23.934 h'),xy=(30,2*np.pi/O/3600),xytext=(42,55),arrowprops={'arrowstyle':'->','color':'#506c7c'});ax.annotate(T('两极：11.967 h','Both poles: 11.967 h'),xy=(90,np.pi/O/3600),xytext=(58,17),arrowprops={'arrowstyle':'->','color':'#506c7c'})
    fig.supxlabel(T('赤道 f=0：本模型没有有限周期的水平惯性圆；不能把它解读为所有赤道运动都不存在。','At f=0 there is no finite-period horizontal inertial circle in this model; other equatorial motions remain possible.'),fontsize=9);save(fig,'inertial-period-'+lang)

    s=np.linspace(-.5,.5,101);fr=np.linspace(.5,1.5,101);hr=np.linspace(.5,1.5,101)
    fig,axs=plt.subplots(1,3,figsize=(13,4.5),layout='constrained')
    for ax,x,y,title,xlabel in zip(axs,[s,fr,hr],[1+s,fr,1/hr],[T('相对涡度','Relative vorticity'),T('行星涡度','Planetary vorticity'),T('层厚','Layer thickness')],['zeta / f0','f / f0','h / H']):
        ax.plot(x,y,c='#08748b',lw=2);ax.set(xlabel=xlabel,ylabel='q / (f0/H)',title=title,ylim=(.4,2.1));ax.grid(alpha=.15)
    fig.supxlabel(T('q=(f+ζ)/h；每幅只改变一个变量，其余取 f=f0、ζ=0、h=H。这是代数敏感性，不是守恒运动过程。','q=(f+zeta)/h. Each panel changes one variable while the others use f=f0, zeta=0, h=H. Algebraic sensitivity, not a conserved trajectory.'),fontsize=9);save(fig,'pv-factors-'+lang)

    fig,axs=plt.subplots(1,2,figsize=(12,5),layout='constrained');z=np.linspace(-1,0,101);axs[0].plot(-(z+1),z,c='#08748b',lw=2);axs[0].axvline(0,c='#8aa4b1',lw=.7)
    axs[0].set(xlabel='w / |w_E|',ylabel=T('内部高度 / H（向上为正）','Interior height / H (upward positive)'),title=T('下沉：内部的竖直应变为负','Downwelling: negative interior vertical strain'))
    axs[0].text(-.93,-.09,T('Ekman 层底：w_E < 0','Ekman-layer base: w_E < 0'),fontsize=10);axs[0].text(-.85,-.93,T('底部：w = 0','Bottom: w = 0'),fontsize=10);axs[0].text(-.95,-.5,T('βv = f ∂w/∂z\n北半球：v < 0，向赤道','beta v = f dw/dz\nNH: v < 0, equatorward'),fontsize=11)
    h=np.linspace(.65,1.35,100);axs[1].plot(h,h,c='#08748b',lw=2);axs[1].scatter([.8,1,1.2],[.8,1,1.2],c=['#b8593c','#173b4c','#08748b'],zorder=3)
    axs[1].set(xlabel='h / h0',ylabel='|f| / |f0|',title=T('小相对涡度下：q≈f/h 守恒','Small relative vorticity: conserve q≈f/h'))
    axs[1].annotate(T('压缩 → 较小 |f|\n→ 向赤道','Compression → smaller |f|\n→ equatorward'),xy=(.8,.8),xytext=(.65,1.12),fontsize=10,arrowprops={'arrowstyle':'->'});axs[1].annotate(T('拉长 → 较大 |f|\n→ 向极地','Stretching → larger |f|\n→ poleward'),xy=(1.2,1.2),xytext=(.96,.66),fontsize=10,arrowprops={'arrowstyle':'->'})
    fig.supxlabel(T('右图是随流物质柱/层厚的示意，不是把固定海盆水深改变；实际流场还须满足边界与输运约束。','Right: an advected material column/layer illustration, not changing fixed basin depth. Actual flow must also satisfy boundary and transport constraints.'),fontsize=9);save(fig,'ekman-sverdrup-'+lang)
values={'Omega_per_s':O,'sidereal_day_h':2*np.pi/O/3600,'pole_period_h':np.pi/O/3600,'30N_period_h':2*np.pi/O/3600,'equator':'No finite horizontal f-plane period'}
(a.out/'calculations.json').write_text(json.dumps(values,indent=2),encoding='utf-8');print(json.dumps(values,indent=2))
